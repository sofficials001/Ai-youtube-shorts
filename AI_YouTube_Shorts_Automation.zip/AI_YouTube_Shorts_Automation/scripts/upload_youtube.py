import os
import sys
import json
from pathlib import Path
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError

CLIENT_ID = os.environ.get('YOUTUBE_CLIENT_ID')
CLIENT_SECRET = os.environ.get('YOUTUBE_CLIENT_SECRET')
REFRESH_TOKEN = os.environ.get('YOUTUBE_REFRESH_TOKEN')
VIDEO = Path('output/final_short.mp4')
STORY = Path('story.json')

if not all([CLIENT_ID, CLIENT_SECRET, REFRESH_TOKEN]):
    print('ERROR: YouTube secrets are missing.')
    sys.exit(1)
if not VIDEO.exists() or not STORY.exists():
    print('ERROR: output/final_short.mp4 or story.json is missing.')
    sys.exit(1)

story = json.loads(STORY.read_text(encoding='utf-8'))
title = str(story.get('title', 'Amazing Hindi Story')).strip()[:95]
description = f'''{title}

एक छोटी लेकिन रहस्यमय कहानी जो अंत तक आपको सोचने पर मजबूर कर देगी।

ऐसी Hindi Shorts Stories के लिए channel को subscribe करें।

#Shorts #HindiShorts #HindiStory #Story #ShortStory #AIStory'''
tags = ['shorts','youtube shorts','hindi shorts','hindi story','short story','hindi kahani','story','mystery story','ai story','viral shorts','trending shorts','kahani']

credentials = Credentials(
    token=None,
    refresh_token=REFRESH_TOKEN,
    token_uri='https://oauth2.googleapis.com/token',
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    scopes=['https://www.googleapis.com/auth/youtube.upload'],
)

print('Refreshing YouTube OAuth token...')
credentials.refresh(Request())
youtube = build('youtube', 'v3', credentials=credentials)

body = {
    'snippet': {
        'title': title,
        'description': description,
        'tags': tags,
        'categoryId': '22',
        'defaultLanguage': 'hi',
        'defaultAudioLanguage': 'hi',
    },
    'status': {
        'privacyStatus': 'public',
        'selfDeclaredMadeForKids': False,
    },
}

media = MediaFileUpload(str(VIDEO), mimetype='video/mp4', resumable=True)

try:
    request = youtube.videos().insert(
        part='snippet,status',
        body=body,
        media_body=media,
        notifySubscribers=True,
    )
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"Upload progress: {int(status.progress()*100)}%")

    video_id = response.get('id')
    if not video_id:
        raise RuntimeError('YouTube did not return a video ID.')

    print('UPLOAD SUCCESSFUL')
    print(f'https://youtube.com/shorts/{video_id}')
except HttpError as exc:
    print('YOUTUBE UPLOAD FAILED:')
    print(exc)
    sys.exit(1)
except Exception as exc:
    print('UPLOAD FAILED:', exc)
    sys.exit(1)

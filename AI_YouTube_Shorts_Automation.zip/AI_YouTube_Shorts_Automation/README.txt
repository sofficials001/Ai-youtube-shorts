AI YouTube Shorts automation

Copy these three files into your GitHub repository:

.github/workflows/test-toddler-video.yml
scripts/generate_short.py
scripts/upload_youtube.py

Required GitHub Secrets:
CLOUDFLARE_API_TOKEN
CLOUDFLARE_ACCOUNT_ID
YOUTUBE_CLIENT_ID
YOUTUBE_CLIENT_SECRET
YOUTUBE_REFRESH_TOKEN

The workflow runs daily at 00:30 UTC (06:00 IST), can also be started manually, and attempts up to 6 Shorts per daily run. It stops when generation/upload fails, including Cloudflare AI limits or YouTube API errors.

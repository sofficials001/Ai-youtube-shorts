AI Tiny World Shorts — Free GitHub Actions + Cloudflare

Included:
- .github/workflows/ai-tiny-world-shorts.yml
- scripts/generate_short.py
- scripts/upload_youtube.py

Creates a 24-second 1080x1920 H.264 silent video with six FLUX-generated 3D-style images, gentle camera motion, and Hindi on-screen captions. It has no voice-over and no audio track. It uses Cloudflare Llama for story JSON, with three complete fallback stories, and Cloudflare FLUX for images.

Install:
1. Extract this ZIP.
2. Copy the three files into those paths in your existing repo.
3. Commit them to the default branch.
4. GitHub -> Actions -> AI Tiny World Shorts -> Run workflow.

Required GitHub secrets (same as current pipeline):
CLOUDFLARE_API_TOKEN
CLOUDFLARE_ACCOUNT_ID
YOUTUBE_CLIENT_ID
YOUTUBE_CLIENT_SECRET
YOUTUBE_REFRESH_TOKEN

The schedule is 00:30 UTC (06:00 IST). The run attempts up to 3 uploads and stops after a generation/upload error. A 429 can mean Cloudflare daily allocation exhaustion or temporary capacity. The free allowance may not support 3 videos. YouTube quota/authentication can also stop uploads.

FLUX creates still images, not true AI video; FFmpeg adds camera movement. Public visibility is requested, but YouTube may restrict uploads from unverified API projects. Disable/delete the old scheduled workflow if you do not want duplicate uploads.
